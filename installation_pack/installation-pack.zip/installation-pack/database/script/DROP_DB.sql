DROP DATABASE sest;
DROP USER 'sest'@'localhost';
DROP USER 'sest'@'127.0.0.1';
DROP USER 'sest'@'%';
